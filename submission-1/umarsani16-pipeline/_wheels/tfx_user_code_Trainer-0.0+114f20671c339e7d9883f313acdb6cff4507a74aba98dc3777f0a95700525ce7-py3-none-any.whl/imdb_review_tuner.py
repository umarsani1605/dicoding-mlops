
from keras_tuner.engine import base_tuner
import keras_tuner as kt
from tensorflow import keras
from tensorflow.keras import layers
from typing import NamedTuple, Dict, Text, Any, List
from tfx.components.trainer.fn_args_utils import FnArgs, DataAccessor
import tensorflow as tf
import tensorflow_transform as tft

# Declare namedtuple field names
TunerFnResult = NamedTuple('TunerFnResult', [('tuner', base_tuner.BaseTuner),
                                             ('fit_kwargs', Dict[Text, Any])])
FEATURE_KEY = "review"
LABEL_KEY = "sentiment"

def transformed_name(key):
    """ Ubah nama fitur hasil transformasi """
    return key + "_xf"

# Callback for the search strategy
stop_early = tf.keras.callbacks.EarlyStopping(monitor='val_accuracy', patience=3)

def gzip_reader_fn(filenames):
    """ Muat dataset reader untuk membaca dataset yang terkompresi """
    return tf.data.TFRecordDataset(filenames, compression_type='GZIP')

def input_fn(file_pattern,
             tf_transform_output,
             num_epochs=None,
             batch_size=32)->tf.data.Dataset:
    """ Ambil fitur hasil transformasi dan buat batch data """

    # Ambil fitur hasil transformasi
    transform_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy())

    # Buat batch data
    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transform_feature_spec,
        reader=gzip_reader_fn,
        num_epochs=num_epochs,
        label_key=transformed_name(LABEL_KEY))

    return dataset

def get_tuner_model(hp):
    """ Buat model machine learning """

    hp_units_1 = hp.Int('units', min_value=32, max_value=128, step=32)
    hp_units_2 = hp.Int('units', min_value=32, max_value=128, step=32)
    hp_learning_rate = hp.Choice('learning_rate', values=[1e-2, 1e-3, 1e-4])

    EMBEDDING_DIM=16
    VOCAB_SIZE = 10000
    SEQUENCE_LENGTH = 100

    vectorize_layer = layers.TextVectorization(
        standardize="lower_and_strip_punctuation",
        max_tokens=VOCAB_SIZE,
        output_mode='int',
        output_sequence_length=SEQUENCE_LENGTH
    )

    inputs = tf.keras.Input(shape=(1,), name=transformed_name(FEATURE_KEY), dtype=tf.string)
    reshaped_narrative = tf.reshape(inputs, [-1])
    x = vectorize_layer(reshaped_narrative)
    x = layers.Embedding(VOCAB_SIZE, EMBEDDING_DIM, name="embedding")(x)

    x = layers.LSTM(hp_units_1, return_sequences=True)(x)
    x = layers.Dropout(0.25)(x)

    x = layers.LSTM(hp_units_2)(x)
    x = layers.Dropout(0.25)(x)

    outputs = layers.Dense(1, activation='sigmoid')(x)

    model = tf.keras.Model(inputs=inputs, outputs = outputs)

    model.compile(
        loss='binary_crossentropy',
        optimizer=keras.optimizers.Adam(learning_rate=hp_learning_rate),
        metrics=[tf.keras.metrics.BinaryAccuracy()]
    )

    model.summary()
    return model

def tuner_fn(fn_args: FnArgs) -> TunerFnResult:
  """ Build the tuner using the KerasTuner API. """

  tuner = kt.Hyperband(get_tuner_model,
                     objective='val_accuracy',
                     max_epochs=10,
                     factor=3,
                     directory=fn_args.working_dir,
                     project_name='kt_hyperband')

  tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)

  train_set = input_fn(fn_args.train_files[0], tf_transform_output)
  val_set = input_fn(fn_args.eval_files[0], tf_transform_output)

  return TunerFnResult(
      tuner=tuner,
      fit_kwargs={
          "callbacks":[stop_early],
          'x': train_set,
          'validation_data': val_set,
          'steps_per_epoch': fn_args.train_steps,
          'validation_steps': fn_args.eval_steps
      }
  )
